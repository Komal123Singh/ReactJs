import * as React from 'react';
import { IGapClaimsLettersProps } from './IGapClaimsLettersProps';
import * as GapClaimsLettersAction from '../Action/GapClaimsLettersAction';
import GapClaimsLettersStore from '../Store/GapClaimsLettersStore';
import { PeoplePicker, PrincipalType } from '@pnp/spfx-controls-react/lib/PeoplePicker';
import { DateTimePicker, DateConvention, TimeConvention } from '@pnp/spfx-controls-react/lib/dateTimePicker';
import { TextField, Dropdown, Checkbox, Label, Link, PrimaryButton, Toggle, ChoiceGroup,IconButton, IIconProps } from '@fluentui/react';
import { Stack } from 'office-ui-fabric-react/lib/Stack';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { SecurityTrimmedControl, PermissionLevel, } from '@pnp/spfx-controls-react/lib/SecurityTrimmedControl';
import { SPPermission } from '@microsoft/sp-page-context';
import ViewGapClaimsLetters from './ViewGapClaimsLetters';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import './GapClaimsLettersCss.css';

import SunEditor from 'suneditor-react';
import 'suneditor/dist/css/suneditor.min.css';
import * as _ from '@microsoft/sp-lodash-subset';

// Global Variable
let absoluteUrl;
let relativeURL;
let uploadedRichTextFiles = [];
let deleteFiles = [];

let localSendToEmail=[];
let localSendToID=[];
let localSendToUser=[];
let localCopyToEmail=[];
let localCopyToID=[];
let localCopyToUser=[];
let localBlindCopyToEmail=[];
let localBlindCopyToID=[];
let localBlindCopyToUser=[];
let localFromEmail=[];
let localFromID=[];
let localFromUser=[];
const url = window.location.href;
const urlObject = new URL(url);
let uniqueId = urlObject.searchParams.get('itemID')==''||urlObject.searchParams.get('itemID')==null?0:parseInt(urlObject.searchParams.get('itemID'));
let isEditMode=false;
let isViewMode=false;
let EditFormDetails;
const stackTokens = { childrenGap: 3 };
const addIcon: IIconProps = { iconName: 'Add' };
const subIcon: IIconProps = { iconName: 'CalculatorMultiply' };
var XMLserialize = new XMLSerializer();

//Business Objects Starts //
export interface MyState 
{
webpartContxt:WebPartContext;
FormAttachment: any;
FormAttachmentNames: any;

GAPAgreeNum : string;
VSCAdj : string;
InsuredLastName : string;
InsuredFirstName : string;
InsuredStreetAddress : string;
InsuredCity : string;
InsuredState : string;
InsZip : string;
mrk_delete : string;
mrk_deleteChoiceArr : any;
SendTo : any;
SendToDefaultItems:string[];
SendToUserItems:string[];
CopyTo : any;
CopyToDefaultItems:string[];
CopyToUserItems:string[];
BlindCopyTo : any;
BlindCopyToDefaultItems:string[];
BlindCopyToUserItems:string[];
From : any;
FromDefaultItems:string[];
FromUserItems:string[];
Date : any;
Subject : string;
Body : string;
}
//Business Objects End //

export default class GapClaimsLetters extends React.Component<IGapClaimsLettersProps, MyState> {
constructor(prop) {
super(prop);
this.state = {
webpartContxt:this.props.context,
FormAttachment: [],
FormAttachmentNames: [],

GAPAgreeNum : '',
VSCAdj : '',
InsuredLastName : '',
InsuredFirstName : '',
InsuredStreetAddress : '',
InsuredCity : '',
InsuredState : '',
InsZip : '',
mrk_delete : '',
mrk_deleteChoiceArr : [],
SendTo : [],
SendToDefaultItems:[],
SendToUserItems:[],
CopyTo : [],
CopyToDefaultItems:[],
CopyToUserItems:[],
BlindCopyTo : [],
BlindCopyToDefaultItems:[],
BlindCopyToUserItems:[],
From : [],
FromDefaultItems:[],
FromUserItems:[],
Date : null,
Subject : '',
Body : '',
};
absoluteUrl = this.props.context.pageContext.site.absoluteUrl;
relativeURL = this.props.context.pageContext.site.serverRelativeUrl;
SPComponentLoader.loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/suneditor@latest/dist/css/suneditor.min.css');
SPComponentLoader.loadScript('https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js');
SPComponentLoader.loadScript('https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js');
SPComponentLoader.loadScript('https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js');
}

  componentDidMount() {
  try {
if(uniqueId!=0)
{
isEditMode=true;
this.getEditFormDetailsComp();
}
else {
this.getFormDefaultDetails();

}
  }
  catch (e) {
  console.log('componentDidMount: ' + e);
  }
  }

getFormDefaultDetails = () => {
 try {
GapClaimsLettersStore.on('insertResultchange', this.assignInsertResultStore);

GapClaimsLettersAction.getmrk_deleteDetails('mrk_delete');
GapClaimsLettersStore.on('mrk_deletechange', this.assignmrk_deleteStore);
} catch (e) {
console.log('getFormDefaultDetails' + e);
  }
  }

getEditFormDetailsComp = () => {
 try {
this.getFormDefaultDetails();
GapClaimsLettersAction.getEditFormDetails(uniqueId);
GapClaimsLettersStore.on('getEditFormDetailschange', this.assignEditFormDetailsStore);
} catch (e) {
console.log('EditClickBtn' + e);
  }
  }

public EditClickBtn = () => {
 try {
 isEditMode = true;
isViewMode = false;
this.getEditFormDetailsComp();
} catch (e) {
console.log('EditClickBtn' + e);
  }
  }

public ViewClickBtn = () => {
 try {
 isEditMode = false;
isViewMode = true;
this.getEditFormDetailsComp();
} catch (e) {
console.log('ViewClickBtn' + e);
  }
  }













public assignEditFormDetailsStore = () => {
EditFormDetails = GapClaimsLettersStore.getEditClickStoreValue();
let domparser = new DOMParser();
let s = new XMLSerializer();
if (EditFormDetails.length != 0)
{

localSendToEmail=[];
localSendToID=[];
localSendToUser=[];
if(EditFormDetails.SendTo!=undefined){
for(var i=0;i < EditFormDetails.SendTo.length; i++){
localSendToEmail.push(EditFormDetails.SendTo[i].EMail);
localSendToID.push(EditFormDetails.SendTo[i].ID);
localSendToUser.push(EditFormDetails.SendTo[i].FirstName + EditFormDetails.SendTo[i].LastName);
}}
localCopyToEmail=[];
localCopyToID=[];
localCopyToUser=[];
if(EditFormDetails.CopyTo!=undefined){
for(var i=0;i < EditFormDetails.CopyTo.length; i++){
localCopyToEmail.push(EditFormDetails.CopyTo[i].EMail);
localCopyToID.push(EditFormDetails.CopyTo[i].ID);
localCopyToUser.push(EditFormDetails.CopyTo[i].FirstName + EditFormDetails.CopyTo[i].LastName);
}}
localBlindCopyToEmail=[];
localBlindCopyToID=[];
localBlindCopyToUser=[];
if(EditFormDetails.BlindCopyTo!=undefined){
for(var i=0;i < EditFormDetails.BlindCopyTo.length; i++){
localBlindCopyToEmail.push(EditFormDetails.BlindCopyTo[i].EMail);
localBlindCopyToID.push(EditFormDetails.BlindCopyTo[i].ID);
localBlindCopyToUser.push(EditFormDetails.BlindCopyTo[i].FirstName + EditFormDetails.BlindCopyTo[i].LastName);
}}
localFromEmail=[];
localFromID=[];
localFromUser=[];
if(EditFormDetails.From!=undefined){
localFromEmail.push(EditFormDetails.From.EMail);
localFromID.push(EditFormDetails.From.ID);
localFromUser.push(EditFormDetails.From.FirstName + EditFormDetails.From.LastName);
}
let parsedBody= domparser.parseFromString(EditFormDetails.Body,'text/html');parsedBody.querySelectorAll('[class*=se-component]').forEach((ext) => {ext.removeAttribute('class');});let serializeBody= s.serializeToString(parsedBody);
this.setState({ 

FormAttachmentNames:EditFormDetails.AttachmentFiles,
GAPAgreeNum:EditFormDetails.GAPAgreeNum,
VSCAdj:EditFormDetails.VSCAdj,
InsuredLastName:EditFormDetails.InsuredLastName,
InsuredFirstName:EditFormDetails.InsuredFirstName,
InsuredStreetAddress:EditFormDetails.InsuredStreetAddress,
InsuredCity:EditFormDetails.InsuredCity,
InsuredState:EditFormDetails.InsuredState,
InsZip:EditFormDetails.InsZip,
mrk_delete:EditFormDetails.mrk_delete,
SendToDefaultItems:localSendToEmail,
SendToUserItems:localSendToUser,
SendTo:localSendToID,
CopyToDefaultItems:localCopyToEmail,
CopyToUserItems:localCopyToUser,
CopyTo:localCopyToID,
BlindCopyToDefaultItems:localBlindCopyToEmail,
BlindCopyToUserItems:localBlindCopyToUser,
BlindCopyTo:localBlindCopyToID,
FromDefaultItems:localFromEmail,
FromUserItems:localFromUser,
From:localFromID,
Date:EditFormDetails.Date != null? new Date(EditFormDetails.Date):null,
Subject:EditFormDetails.Subject,
Body: _.unescape(serializeBody),
});
}
}



public assignmrk_deleteStore= () => {
try {
let mrk_deleteChoice= [];
if(GapClaimsLettersStore.getmrk_deleteChoiceStoreValue().length!=0)
GapClaimsLettersStore.getmrk_deleteChoiceStoreValue().map((item) => {
mrk_deleteChoice.push({key:item,text:item,id:'mrk_delete'});
});
this.setState({mrk_deleteChoiceArr: mrk_deleteChoice});
} catch (e) {
console.log('assignmrk_deleteStore: ' + e);
}
}

// Call action save Result method
public assignInsertResultStore = () => {
try {
if (GapClaimsLettersStore.getInserResultStoreValue() != undefined) {
window.location.href = url;
}
} catch (e) {
console.log('assignInsertResultStore: ' + e);
}
}
// Call action save method
public insertForm = () => {
 try {
if (uniqueId == 0) {
GapClaimsLettersAction.saveForm(this.state.GAPAgreeNum,this.state.VSCAdj,this.state.InsuredLastName,this.state.InsuredFirstName,this.state.InsuredStreetAddress,this.state.InsuredCity,this.state.InsuredState,this.state.InsZip,this.state.mrk_delete,this.state.SendTo,this.state.CopyTo,this.state.BlindCopyTo,this.state.From,this.state.Date,this.state.Subject,this.state.Body,uploadedRichTextFilesthis.state.FormAttachment)
  }
else
{
GapClaimsLettersAction.updateForm(uniqueId,this.state.GAPAgreeNum,this.state.VSCAdj,this.state.InsuredLastName,this.state.InsuredFirstName,this.state.InsuredStreetAddress,this.state.InsuredCity,this.state.InsuredState,this.state.InsZip,this.state.mrk_delete,this.state.SendTo,this.state.CopyTo,this.state.BlindCopyTo,this.state.From,this.state.Date,this.state.Subject,this.state.Body,uploadedRichTextFilesthis.state.FormAttachment,deleteFiles)
  }
  }
  catch (e) {
  console.log('insertForm: ' + e);
  }
  }

// Get Input Details
private inputFormChange = (inputValue) => {
 try {
 switch (inputValue.target.name) {

case 'GAPAgreeNum':
{
this.setState({GAPAgreeNum :inputValue.target.value});
break;
}
case 'VSCAdj':
{
this.setState({VSCAdj :inputValue.target.value});
break;
}
case 'InsuredLastName':
{
this.setState({InsuredLastName :inputValue.target.value});
break;
}
case 'InsuredFirstName':
{
this.setState({InsuredFirstName :inputValue.target.value});
break;
}
case 'InsuredStreetAddress':
{
this.setState({InsuredStreetAddress :inputValue.target.value});
break;
}
case 'InsuredCity':
{
this.setState({InsuredCity :inputValue.target.value});
break;
}
case 'InsuredState':
{
this.setState({InsuredState :inputValue.target.value});
break;
}
case 'InsZip':
{
this.setState({InsZip :inputValue.target.value});
break;
}
case 'SendTo':
{
this.setState({SendTo :inputValue.target.value});
break;
}
case 'CopyTo':
{
this.setState({CopyTo :inputValue.target.value});
break;
}
case 'BlindCopyTo':
{
this.setState({BlindCopyTo :inputValue.target.value});
break;
}
case 'From':
{
this.setState({From :inputValue.target.value});
break;
}
case 'Date':
{
this.setState({Date :inputValue.target.value});
break;
}
case 'Subject':
{
this.setState({Subject :inputValue.target.value});
break;
}
case 'Body':
{
this.setState({Body :inputValue.target.value});
break;
}
 }
  }
  catch (e) {
  console.log('inputFormChange: ' + e);
  }
  }

// Get Input RichText Details
private handleRichTextChange = (fieldName, content) => {
 try {
 switch (fieldName) {

case 'Body':
this.setState({ Body: content });
break;
 }
  }
  catch (e) {
  console.log('handleRichTextChange: ' + e);
  }
  }


private handleImageUpload(targetImgElement, index, state, imageInfo, remainingFilesCount) {
if (imageInfo != null) {
let files = uploadedRichTextFiles;
let dataURI = imageInfo.src;
 let fileName = imageInfo.name;
if (dataURI.split(',')[0].indexOf('base64') >= 0) {
var arr = dataURI.split(','),
mime = arr[0].match(/:(.*?);/)[1],
bstr = atob(arr[1]),
n = bstr.length,
u8arr = new Uint8Array(n);
while (n--) {
u8arr[n] = bstr.charCodeAt(n);
}
const file = new File([u8arr], fileName, { type: mime });
let fExists = files.some((f) => f['name'] === file['name']);
if (!fExists) {
files.push(file);
}
uploadedRichTextFiles = files;
}
}
}


handleAttachmentChange = (chTarget) => {
try {
let target = chTarget.target;
let fileInfos
if (target.files.length !== 0) {
uniqueId != 0 ?fileInfos = this.state.FormAttachment : [];
for (let fileItem of target.files) {
let fileRead = new FileReader();
fileRead.onload = async (e) => {
fileInfos.push({ name: 'FormAtach_' + fileItem.name,content: fileRead.result});
this.setState({ FormAttachment: fileInfos });
}
fileRead.readAsDataURL(fileItem);
}
}
}
catch (e) {
console.log('handleAttachmentChange: ' + e);
}
}


bindAttachmentFileNames() {
try {
return this.state.FormAttachmentNames.map((item) => {
if (item.FileName.indexOf('FormAtach_') != -1) {
let fileName = item.FileName.replace('FormAtach_', '');
return (
<div><span><Link target='_blank' href={item.ServerRelativePath.DecodedUrl}>{fileName}</Link><IconButton className='mt-1' iconProps={{ iconName: 'CalculatorMultiply' }} title='Delete' ariaLabel='Delete' onClick={this.addDeleteFiles.bind(this, fileName)} /></span></div>
)
}});
}
catch (e) {
console.log('bindAttachmentFileNames ' + e);
}
}

addDeleteFiles = (fileName) => {
try {
let tempAttachFileName = this.state.FormAttachmentNames;
var index = tempAttachFileName.map(p => p.FileName).indexOf('FormAtach_' + fileName);
tempAttachFileName.splice(index, 1);
deleteFiles.push('FormAtach_' + fileName);
this.setState({ FormAttachmentNames: tempAttachFileName });
}
catch (e) {
console.log('addDeleteFiles ' + e);
}
}

// Get DropDownDetails
private inputDropDownDetailsChange = (inputValue) => {
 try {
 switch (inputValue.id) {

 }
  }
  catch (e) {
  console.log('inputDropDownDetailsChange: ' + e);
  }
  }


private _getSendToPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
}this.setState({ SendTo: peoplePickArr });
}
private _getCopyToPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
}this.setState({ CopyTo: peoplePickArr });
}
private _getBlindCopyToPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
}this.setState({ BlindCopyTo: peoplePickArr });
}
private _getFromPeoplePickerItems = (items: any[]) => {
let peoplePickArr = [];
for (let item in items) {
peoplePickArr.push(items[item].id);
}this.setState({ From: peoplePickArr });
}


private _getDateDatePickerItems = (items) => {
this.setState({ Date: items });
}




private mrk_deleteRadioBtnChange = (items) => {
items.target.innerText!=''?this.setState({ mrk_delete: items.target.innerText }):null;
}

PrintScreen = () => {
try {
window.print();
} catch (e) {
console.log('PrintScreen: ' + e);
}
}
//Render Method //
public render(): React.ReactElement<IGapClaimsLettersProps> {
return (
 <div className='container'> 
 <div className='border p-3' style={{backgroundColor:this.props.bannerBackground}}>
 <div className='row'>
 <div className='col-md-6'><h3>{this.props.description}</h3></div>
 <div className='col-md-6 text-right'><img src={this.props.logo} alt='Logo' width='50' height='50' /></div>
 </div>
 </div>
 {isViewMode == true && isEditMode == false? 
 <div>
 <div className='buttonCls text-right'> 
 <PrimaryButton className='' text='Close' allowDisabledFocus />
 <PrimaryButton className='ml-1' text='Edit' onClick={this.EditClickBtn} allowDisabledFocus />
 <PrimaryButton className='ml-1' text='Print' onClick={this.PrintScreen} allowDisabledFocus />
 </div><div style={{backgroundColor:this.props.bodyBackground}}><ViewGapClaimsLetters {...this.state}/></div></div>: 
 <div>
 <div className='buttonCls mt-2 text-right'> 
 <PrimaryButton className='' text='Close' allowDisabledFocus />
 {isEditMode == true ? <PrimaryButton className='ml-1' text='View' onClick={this.ViewClickBtn} allowDisabledFocus />: null}
 <PrimaryButton className='ml-1' text='Submit' onClick={this.insertForm} allowDisabledFocus />
 </div>

<div className='border p-3 mt-2'>
<div className='row'>
<div className='col-md-6'>
 <TextField className='w-100' label='GAP Agreement #' value={this.state.GAPAgreeNum} name='GAPAgreeNum' onChange={this.inputFormChange} />
</div>
<div className='col-md-6'>
 <TextField className='w-100' label='Gap Adjuster' value={this.state.VSCAdj} name='VSCAdj' onChange={this.inputFormChange} />
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <TextField className='w-100' label='Claimant Last Name' value={this.state.InsuredLastName} name='InsuredLastName' onChange={this.inputFormChange} />
</div>
<div className='col-md-6'>
 <TextField className='w-100' label='First Name' value={this.state.InsuredFirstName} name='InsuredFirstName' onChange={this.inputFormChange} />
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <TextField className='w-100' label='Claimant Address' value={this.state.InsuredStreetAddress} name='InsuredStreetAddress' onChange={this.inputFormChange} />
</div>
<div className='col-md-6'>
 <TextField className='w-100' label='Claimant City' value={this.state.InsuredCity} name='InsuredCity' onChange={this.inputFormChange} />
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <TextField className='w-100' label='Claimant State' value={this.state.InsuredState} name='InsuredState' onChange={this.inputFormChange} />
</div>
<div className='col-md-6'>
 <TextField className='w-100' label='Claimant Zip' value={this.state.InsZip} name='InsZip' onChange={this.inputFormChange} />
</div>
</div>
<div className='row'>
<div className='col-md-6'>
<ChoiceGroup className='w-100 inlineflex' label='Mark Delete' selectedKey={this.state.mrk_delete} options={this.state.mrk_deleteChoiceArr} onClick={this.mrk_deleteRadioBtnChange} />
</div>
</div>
</div>
<div className='border p-3 mt-2'>
<div className='row'>
<div className='col-md-12'>
<div className='w-25'><PeoplePicker context ={ this.props.context} titleText = 'To'
personSelectionLimit ={ 3} showtooltip ={ true} required ={ true} disabled ={ false} ensureUser ={ true} onChange ={ this._getSendToPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.SendToDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div>
</div>
</div>
<div className='row'>
<div className='col-md-12'>
<div className='w-25'><PeoplePicker context ={ this.props.context} titleText = 'Copy To'
personSelectionLimit ={ 3} showtooltip ={ true} required ={ true} disabled ={ false} ensureUser ={ true} onChange ={ this._getCopyToPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.CopyToDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div>
</div>
</div>
<div className='row'>
<div className='col-md-12'>
<div className='w-25'><PeoplePicker context ={ this.props.context} titleText = 'Blind Copy To'
personSelectionLimit ={ 3} showtooltip ={ true} required ={ true} disabled ={ false} ensureUser ={ true} onChange ={ this._getBlindCopyToPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.BlindCopyToDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div>
</div>
</div>
<div className='row'>
<div className='col-md-12'>
<div className='w-25'><PeoplePicker context ={ this.props.context} titleText = 'From'
personSelectionLimit ={1} showtooltip ={ true} required ={ true} disabled ={ false} ensureUser ={ true} onChange ={ this._getFromPeoplePickerItems}
showHiddenInUI ={ false} defaultSelectedUsers ={ this.state.FromDefaultItems} principalTypes ={[PrincipalType.User]} resolveDelay ={ 1000}/></div>
</div>
</div>
<div className='row'>
<div className='col-md-12'>
<div className='w-25'><DateTimePicker label='Date '  dateConvention={DateConvention.DateTime} showLabels={false}
value={this.state.Date} onChange={this._getDateDatePickerItems} /></div>

</div>
</div>
<div className='row'>
<div className='col-md-12'>
 <TextField className='w-25' label='Subject ' value={this.state.Subject} name='Subject' onChange={this.inputFormChange} />
</div>
</div>
</div>
<div className='border p-3 mt-2'>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-25'> . </Label>
<SunEditor enableToolbar={true} lang='en' placeholder='Please type here...' setContents={this.state.Body} autoFocus={true} setOptions={{
mode: 'classic', minHeight: '170px', buttonList: [
['font', 'fontSize', 'formatBlock'], ['paragraphStyle', 'blockquote'], ['bold', 'underline', 'italic', 'strike'],
['table', 'link', 'image'],],}}
onChange={this.handleRichTextChange.bind(this,'Body')}
onImageUpload={this.handleImageUpload}/>
</div>
</div>
</div>

<div className='border p-3 mt-2'>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold'> Attachments </Label>
<input className='ReactFieldEditor - Attachments - UploadInput' type='file' name='attachmentFiles' title='Attach Files' aria-required='false' aria-label='Attach Files' multiple onChange={this.handleAttachmentChange.bind(this)} />
<div>
{this.bindAttachmentFileNames()}
</div>
</div>
</div>
</div>
 </div>}
 </div>
);
}}