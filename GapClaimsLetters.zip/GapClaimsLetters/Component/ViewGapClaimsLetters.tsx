import * as React from 'react';
import { MyState } from './GapClaimsLetters';
import {Label} from '@fluentui/react';
import { SecurityTrimmedControl, PermissionLevel, } from '@pnp/spfx-controls-react/lib/SecurityTrimmedControl';
import { SPPermission } from '@microsoft/sp-page-context';

export default class ViewGapClaimsLetters extends React.Component<MyState> {

bindAttachmentFileNames() {
try {
return this.state.FormAttachmentNames.map((item) => {
if (item.FileName.indexOf('FormAtach_') != -1) {
let fileName = item.FileName.replace('FormAtach_', '');
return (
<div><span><Link target='_blank' href={item.ServerRelativePath.DecodedUrl}>{fileName}</Link><IconButton className='mt-1' iconProps={{ iconName: 'CalculatorMultiply' }} title='Delete' ariaLabel='Delete' onClick={this.addDeleteFiles.bind(this, fileName)} /></span></div>
)
}});
}
catch (e) {
console.log('bindAttachmentFileNames ' + e);
}
}

addDeleteFiles = (fileName) => {
try {
let tempAttachFileName = this.state.FormAttachmentNames;
var index = tempAttachFileName.map(p => p.FileName).indexOf('FormAtach_' + fileName);
tempAttachFileName.splice(index, 1);
deleteFiles.push('FormAtach_' + fileName);
this.setState({ FormAttachmentNames: tempAttachFileName });
}
catch (e) {
console.log('addDeleteFiles ' + e);
}
}
render() {
return (
<div>


<div className='border p-3 mt-1'>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> GAP Agreement #</Label><span>{this.props.GAPAgreeNum}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Gap Adjuster</Label><span>{this.props.VSCAdj}</span>
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant Last Name</Label><span>{this.props.InsuredLastName}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> First Name</Label><span>{this.props.InsuredFirstName}</span>
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant Address</Label><span>{this.props.InsuredStreetAddress}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant City</Label><span>{this.props.InsuredCity}</span>
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant State</Label><span>{this.props.InsuredState}</span>
</div>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Claimant Zip</Label><span>{this.props.InsZip}</span>
</div>
</div>
<div className='row'>
<div className='col-md-6'>
 <Label className='font-weight-bold w-100'> Mark Delete</Label><span>{this.props.mrk_delete}</span>
</div>
</div>
</div>

<div className='border p-3 mt-1'>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-25'> To </Label>
{this.props.SendToUserItems.length > 0 ? this.props.SendToUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-25'> Copy To </Label>
{this.props.CopyToUserItems.length > 0 ? this.props.CopyToUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-25'> Blind Copy To </Label>
{this.props.BlindCopyToUserItems.length > 0 ? this.props.BlindCopyToUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-25'> From </Label>
{this.props.FromUserItems.length > 0 ? this.props.FromUserItems.map((team, index) =>
<span>{team}</span>
):null}
</div>
</div>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold w-25'> Date</Label><span>{this.props.Date!=undefined&&this.props.Date!=''&&this.props.Date!=null?this.props.Date.toUTCString():null}</span>
</div>
</div>
<div className='row'>
<div className='col-md-12'>
 <Label className='font-weight-bold w-25'> Subject </Label><span>{this.props.Subject}</span>
</div>
</div>
</div>

<div className='border p-3 mt-1'>
<div className='row'>
<div className='col-md-12'>
 <Label className='font-weight-bold w-25'> .</Label><span><div dangerouslySetInnerHTML={{ __html: this.props.Body }}></div></span>
</div>
</div>
</div>

<div className='border p-3 mt-2'>
<div className='row'>
<div className='col-md-12'>
<Label className='font-weight-bold'> Attachments </Label>
<div>
{this.bindAttachmentFileNames()}
</div>
</div>
</div>
</div>
</div>
)
}
}