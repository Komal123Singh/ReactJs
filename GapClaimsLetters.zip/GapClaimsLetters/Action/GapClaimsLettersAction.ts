import { Dispatcher } from 'simplr-flux';
import { sp } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import '@pnp/sp/attachments';
import { SPHttpClient} from '@microsoft/sp-http';

// Get the edit click details
const getEditFormDetails = (Id) => {
sp.web.lists.getByTitle('Letters').items.getById(Id).select('*',
'AttachmentFiles',
'SendTo/ID','SendTo/EMail','SendTo/FirstName','SendTo/LastName',
'CopyTo/ID','CopyTo/EMail','CopyTo/FirstName','CopyTo/LastName',
'BlindCopyTo/ID','BlindCopyTo/EMail','BlindCopyTo/FirstName','BlindCopyTo/LastName',
'From/ID','From/EMail','From/FirstName','From/LastName',).expand('AttachmentFiles','SendTo','CopyTo','BlindCopyTo','From',).get().then(res => {
Dispatcher.dispatch({ type: 'getEditFormDetailsType', response:res});
}).catch(error => {
console.log('getEditFormDetails ' + error);
});
  }
export {getEditFormDetails};

// Get Input Details
const saveForm = (GAPAgreeNum,VSCAdj,InsuredLastName,InsuredFirstName,InsuredStreetAddress,InsuredCity,InsuredState,InsZip,mrk_delete,SendTo,CopyTo,BlindCopyTo,From,Date,Subject,Body,uploadedRichTextFilesAttachmentFiles)=> {
sp.web.lists.getByTitle('Letters').items.add({

'GAPAgreeNum': GAPAgreeNum,
'VSCAdj': VSCAdj,
'InsuredLastName': InsuredLastName,
'InsuredFirstName': InsuredFirstName,
'InsuredStreetAddress': InsuredStreetAddress,
'InsuredCity': InsuredCity,
'InsuredState': InsuredState,
'InsZip': InsZip,
'mrk_delete': mrk_delete,
'SendToId': {results:SendTo},
'CopyToId': {results:CopyTo},
'BlindCopyToId': {results:BlindCopyTo},
'FromId': From.length > 0 ? From[0] : null,
'Date': Date,
'Subject': Subject,
'Body': Body,
}).then(res => {

if (res.data != undefined && res.data != null) {
if(AttachmentFiles.length > 0)
{
insertFormAttachment(res.data.Id, AttachmentFiles);
} else 
{
Dispatcher.dispatch({ type: 'insertResultType', response: res.data.Id });
}
}


if(res != null && uploadedRichTextFiles.length > 0) {
insertAttachRichTextFile(res, uploadedRichTextFiles, 0);
}
}).catch(error => {
console.log('saveForm ' + error);
});
}
export {saveForm};

// Update Existing Item
const updateForm = (uniqueId,GAPAgreeNum,VSCAdj,InsuredLastName,InsuredFirstName,InsuredStreetAddress,InsuredCity,InsuredState,InsZip,mrk_delete,SendTo,CopyTo,BlindCopyTo,From,Date,Subject,Body,uploadedRichTextFilesAttachmentFiles, deleteFiles)=> {
sp.web.lists.getByTitle('Letters').items.getById(uniqueId).update({

'GAPAgreeNum': GAPAgreeNum,
'VSCAdj': VSCAdj,
'InsuredLastName': InsuredLastName,
'InsuredFirstName': InsuredFirstName,
'InsuredStreetAddress': InsuredStreetAddress,
'InsuredCity': InsuredCity,
'InsuredState': InsuredState,
'InsZip': InsZip,
'mrk_delete': mrk_delete,
'SendToId': {results:SendTo},
'CopyToId': {results:CopyTo},
'BlindCopyToId': {results:BlindCopyTo},
'FromId': From.length > 0 ? From[0] : null,
'Date': Date,
'Subject': Subject,
'Body': Body,
}).then(res => {

 if (res.data != undefined && res.data != null) {
if (deleteFiles.length > 0) {
DeleteFormAttachment(uniqueId, deleteFiles, AttachmentFiles);
} else if (AttachmentFiles.length > 0) {
insertFormAttachment(uniqueId, AttachmentFiles);
} else {
Dispatcher.dispatch({ type: 'insertResultType', response: uniqueId });
}
}


if(res != null) {
updateAttachRichTextFile(res, uploadedRichTextFiles, uniqueId);
}
}).catch(error => {
console.log('updateForm ' + error);
});
  }
export {updateForm};


const insertFormAttachment = (uniqueID, AttachmentFiles) => {
sp.web.lists.getByTitle('Letters').items.getById(uniqueID).attachmentFiles.addMultiple(AttachmentFiles).
then(res => {
Dispatcher.dispatch({ type: 'insertResultType', response: uniqueID });
}).catch(error => {
console.log('insertFormAttachment ' + error);
});
}
export { insertFormAttachment };


const DeleteFormAttachment = (uniqueID, deleteFiles, AttachmentFiles) => {
let deleteFilesNames = deleteFiles.map(a => a);
sp.web.lists.getByTitle('Letters').items.getById(uniqueID).attachmentFiles.deleteMultiple(...deleteFilesNames).
then(res => {
if (AttachmentFiles.length > 0) {
insertFormAttachment(uniqueID, AttachmentFiles);
}else {
Dispatcher.dispatch({ type: 'insertResultType', response: uniqueID });
}
}).catch(error => {
console.log('insertFormAttachment ' + error);
});
}
export { DeleteFormAttachment };


const insertAttachRichTextFile = (results, files, itemId) => {
let domparser = new DOMParser();
let fileInfos = [];
if (files != null) {
for (let f of files) {
let fileRead = new FileReader();
fileRead.onloadend = (e) => {
fileInfos.push({
name: f.name,
content: fileRead.result,
});
results.item.attachmentFiles.addMultiple(fileInfos).then(() => {
results.item
.select('ID,AttachmentFiles,Body')
.expand('AttachmentFiles').get().then(async (results: any) => {
let itemID = results.ID;
let fileData = results.AttachmentFiles;

let Body = results.Body;

let parsedBody = domparser.parseFromString(Body,'text/html');
await Promise.all([

await parsedBody.querySelectorAll('img').forEach((img) => {fileData.forEach((fData) => {
img.getAttribute('data-file-name') ===fData['FileName']? img.setAttribute('src',fData['ServerRelativeUrl'])
: null;});}),
]);
updateRichItem(itemID ,parsedBody);
});
});};
fileRead.readAsArrayBuffer(f);
}}}
export { insertAttachRichTextFile };


const updateAttachRichTextFile = (results, files, itemId) => {
let domparser = new DOMParser();
sp.web.lists.getByTitle('Letters').items.getById(itemId).select('ID,AttachmentFiles,Body')
.expand('AttachmentFiles').get().then(async (fileResults: any) => {
let fileData = fileResults.AttachmentFiles;
let aFiles = [...fileData];

let Body = fileResults.Body;
aFiles.forEach(async (aFile) => {
let isExists = files.some((f) => f['name'] === aFile['FileName']);
if (isExists) {
parseUpdate(fileData, itemId,Body)
}
});
if (files.length > 0) {
let fileInfos = [];
for (let f of files) {
let fileRead = new FileReader();
fileRead.onloadend = (e) => {
fileInfos.push({
name: f.name,
content: fileRead.result,
});
results.item.attachmentFiles.addMultiple(fileInfos).then(() => {
results.item.select('ID,AttachmentFiles,Body')
.expand('AttachmentFiles').get().then(async (results: any) => {
let itemID = results.ID;
let fileData = results.AttachmentFiles;

let Body = results.Body;
parseUpdate(fileData, itemId,Body);


let parsedBody = domparser.parseFromString(Body,'text/html');
await Promise.all([


await parsedBody.querySelectorAll('img').forEach((img) => {fileData.forEach((fData) => {
img.getAttribute('data-file-name') ===fData['FileName']? img.setAttribute('src',fData['ServerRelativeUrl'])
: null;});}),

]);

updateRichItem(itemID ,parsedBody);
});
});
};
fileRead.readAsArrayBuffer(f);
}}
else if (files.length == 0) {
parseUpdate(fileData, itemId,Body)
}});}
export { updateAttachRichTextFile };


const updateRichItem = (itemID ,parsedBody) => {
let s = new XMLSerializer();

let serializeBody = s.serializeToString(parsedBody);
sp.web.lists.getByTitle('Letters').items.getById(itemID).update({

'Body':serializeBody,
}).then(res => {
if (res.data != undefined) {
Dispatcher.dispatch({ type: 'insertResultType', response: itemID });
}
}).catch(error => {
console.log('updateRichItem ' + error);
});
}
export { updateRichItem };

const parseUpdate = async (fileData,itemId,Body) => {
let fileLevlInfos = [];
let domparser = new DOMParser();


let parsedBody = domparser.parseFromString(Body,'text/html');

parsedBody.querySelectorAll('img').forEach((img) => {
let iName = img.getAttribute('data-file-name');
fileData.forEach((fData) => {
img.getAttribute('data-file-name') === fData['FileName']
? img.setAttribute('src', fData['ServerRelativeUrl']): null;
});
fileLevlInfos.indexOf(iName)
? console.log('exisitng file')
: fileLevlInfos.push(iName);
});
let item = await sp.web.lists.getByTitle('Letters').items.getById(itemId);
if (fileData.length !== fileLevlInfos.length) {
let fInfos = [];
fileData.forEach((aFile) => {
fInfos.push(aFile['FileName']);
});
let ainfos = fInfos.join('","');
let infos = ainfos.toString();
fileLevlInfos.length !== 0
? fileLevlInfos.forEach((rFile) => {
fileData.forEach(async (aFile) => {
rFile === aFile['FileName']? console.log(''): await item.attachmentFiles
.getByName(aFile['FileName']).delete();});})
: await item.attachmentFiles.deleteMultiple(infos);
}
}
export { parseUpdate };


const getmrk_deleteDetails = (Title) => {
sp.web.lists.getByTitle('Letters').fields.getByTitle(Title).get().then(res => {
Dispatcher.dispatch({ type: 'getmrk_deleteChoiceType', response:res});
}).catch(error => {
console.log('getDetails ' + error);
});
}
export {getmrk_deleteDetails};

